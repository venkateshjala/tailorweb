import { useState, useCallback } from 'react';

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  address: string;
  createdAt: Date;
}

export interface Measurement {
  id: string;
  name: string;
  value: string;
  unit: string;
}

export interface OrderItem {
  id: string;
  productType: 'shirt' | 'pant' | 'suit' | 'kurta' | 'blazer' | 'other';
  productName: string;
  measurements: Measurement[];
  referenceImage?: string;
  notes: string;
}

export interface Order {
  id: string;
  invoiceNumber: string;
  customerId: string;
  customerName: string;
  items: OrderItem[];
  totalAmount: number;
  advanceReceived: number;
  balanceAmount: number;
  status: 'pending' | 'processing' | 'completed';
  createdAt: Date;
  completedAt?: Date;
  whatsappSent: boolean;
}

export const mockCustomers: Customer[] = [
  { id: '1', name: 'Rajesh Kumar', phone: '+91 98765 43210', email: 'rajesh@email.com', address: '123 MG Road, Mumbai', createdAt: new Date('2024-01-15') },
  { id: '2', name: 'Amit Sharma', phone: '+91 98765 43211', email: 'amit@email.com', address: '456 Park Street, Delhi', createdAt: new Date('2024-02-20') },
  { id: '3', name: 'Priya Patel', phone: '+91 98765 43212', email: 'priya@email.com', address: '789 Church Road, Bangalore', createdAt: new Date('2024-03-10') },
];

export const mockOrders: Order[] = [
  {
    id: '1',
    invoiceNumber: 'INV-2024-001',
    customerId: '1',
    customerName: 'Rajesh Kumar',
    items: [
      {
        id: '1',
        productType: 'shirt',
        productName: 'Formal Shirt',
        measurements: [
          { id: '1', name: 'Chest', value: '42', unit: 'inches' },
          { id: '2', name: 'Shoulder', value: '18', unit: 'inches' },
          { id: '3', name: 'Sleeve Length', value: '25', unit: 'inches' },
        ],
        notes: 'Blue fabric, slim fit',
      },
    ],
    totalAmount: 2500,
    advanceReceived: 1000,
    balanceAmount: 1500,
    status: 'pending',
    createdAt: new Date('2024-12-01'),
    whatsappSent: false,
  },
  {
    id: '2',
    invoiceNumber: 'INV-2024-002',
    customerId: '2',
    customerName: 'Amit Sharma',
    items: [
      {
        id: '2',
        productType: 'suit',
        productName: 'Wedding Suit',
        measurements: [
          { id: '1', name: 'Chest', value: '44', unit: 'inches' },
          { id: '2', name: 'Waist', value: '36', unit: 'inches' },
        ],
        notes: 'Navy blue, three-piece',
      },
    ],
    totalAmount: 15000,
    advanceReceived: 7500,
    balanceAmount: 7500,
    status: 'processing',
    createdAt: new Date('2024-11-25'),
    whatsappSent: false,
  },
  {
    id: '3',
    invoiceNumber: 'INV-2024-003',
    customerId: '3',
    customerName: 'Priya Patel',
    items: [
      {
        id: '3',
        productType: 'kurta',
        productName: 'Designer Kurta',
        measurements: [
          { id: '1', name: 'Length', value: '38', unit: 'inches' },
          { id: '2', name: 'Bust', value: '36', unit: 'inches' },
        ],
        notes: 'Silk fabric, embroidery work',
      },
    ],
    totalAmount: 5000,
    advanceReceived: 5000,
    balanceAmount: 0,
    status: 'completed',
    createdAt: new Date('2024-11-20'),
    completedAt: new Date('2024-12-05'),
    whatsappSent: true,
  },
];

export const productTypes = [
  { id: 'shirt', name: 'Shirt', icon: '👔' },
  { id: 'pant', name: 'Pant/Trouser', icon: '👖' },
  { id: 'suit', name: 'Suit', icon: '🤵' },
  { id: 'kurta', name: 'Kurta', icon: '👘' },
  { id: 'blazer', name: 'Blazer', icon: '🧥' },
  { id: 'other', name: 'Other', icon: '✂️' },
];

export const measurementTemplates: Record<string, { name: string; unit: string }[]> = {
  shirt: [
    { name: 'Chest', unit: 'inches' },
    { name: 'Shoulder', unit: 'inches' },
    { name: 'Sleeve Length', unit: 'inches' },
    { name: 'Collar', unit: 'inches' },
    { name: 'Body Length', unit: 'inches' },
    { name: 'Bicep', unit: 'inches' },
    { name: 'Cuff', unit: 'inches' },
  ],
  pant: [
    { name: 'Waist', unit: 'inches' },
    { name: 'Hip', unit: 'inches' },
    { name: 'Thigh', unit: 'inches' },
    { name: 'Inseam', unit: 'inches' },
    { name: 'Outseam', unit: 'inches' },
    { name: 'Knee', unit: 'inches' },
    { name: 'Bottom/Hem', unit: 'inches' },
  ],
  suit: [
    { name: 'Chest', unit: 'inches' },
    { name: 'Waist', unit: 'inches' },
    { name: 'Shoulder', unit: 'inches' },
    { name: 'Sleeve Length', unit: 'inches' },
    { name: 'Jacket Length', unit: 'inches' },
    { name: 'Trouser Waist', unit: 'inches' },
    { name: 'Trouser Length', unit: 'inches' },
  ],
  kurta: [
    { name: 'Length', unit: 'inches' },
    { name: 'Chest/Bust', unit: 'inches' },
    { name: 'Shoulder', unit: 'inches' },
    { name: 'Sleeve Length', unit: 'inches' },
    { name: 'Armhole', unit: 'inches' },
    { name: 'Neck Round', unit: 'inches' },
  ],
  blazer: [
    { name: 'Chest', unit: 'inches' },
    { name: 'Waist', unit: 'inches' },
    { name: 'Shoulder', unit: 'inches' },
    { name: 'Sleeve Length', unit: 'inches' },
    { name: 'Blazer Length', unit: 'inches' },
  ],
  other: [
    { name: 'Measurement 1', unit: 'inches' },
    { name: 'Measurement 2', unit: 'inches' },
    { name: 'Measurement 3', unit: 'inches' },
  ],
};

export function useAuth() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);

  const login = useCallback((email: string, password: string) => {
    if (email && password) {
      setIsAuthenticated(true);
      setUser({ name: 'Admin User', email });
      return true;
    }
    return false;
  }, []);

  const logout = useCallback(() => {
    setIsAuthenticated(false);
    setUser(null);
  }, []);

  return { isAuthenticated, user, login, logout };
}
