import { useState, useCallback } from "react";
import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import Customers from "@/pages/customers";
import Orders from "@/pages/orders";
import NewOrder from "@/pages/new-order";
import Reports from "@/pages/reports";
import Layout from "@/components/layout";
import NotFound from "@/pages/not-found";

function Router({ onLogout, userName }: { onLogout: () => void; userName?: string }) {
  return (
    <Layout onLogout={onLogout} userName={userName}>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/customers" component={Customers} />
        <Route path="/orders" component={Orders} />
        <Route path="/new-order" component={NewOrder} />
        <Route path="/reports" component={Reports} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<{ name: string; email: string } | null>(null);

  const handleLogin = useCallback((email: string, password: string) => {
    if (email && password) {
      setIsAuthenticated(true);
      setUser({ name: 'Admin User', email });
    }
  }, []);

  const handleLogout = useCallback(() => {
    setIsAuthenticated(false);
    setUser(null);
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        {isAuthenticated ? (
          <Router onLogout={handleLogout} userName={user?.name} />
        ) : (
          <Login onLogin={handleLogin} />
        )}
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
