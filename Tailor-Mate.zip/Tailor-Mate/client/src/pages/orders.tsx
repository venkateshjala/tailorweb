import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Search, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  IndianRupee,
  MessageCircle,
  Eye,
  CreditCard
} from 'lucide-react';
import { mockOrders, Order } from '@/lib/store';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>(mockOrders);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [paymentAmount, setPaymentAmount] = useState('');
  const { toast } = useToast();

  const filteredOrders = orders.filter(order => {
    const matchesSearch = 
      order.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      order.customerName.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (activeTab === 'all') return matchesSearch;
    return matchesSearch && order.status === activeTab;
  });

  const handlePayment = () => {
    if (!selectedOrder || !paymentAmount) return;
    
    const amount = parseFloat(paymentAmount);
    if (isNaN(amount) || amount <= 0 || amount > selectedOrder.balanceAmount) {
      toast({
        title: 'Invalid amount',
        description: 'Please enter a valid payment amount',
        variant: 'destructive',
      });
      return;
    }

    setOrders(orders.map(order => {
      if (order.id === selectedOrder.id) {
        const newBalance = order.balanceAmount - amount;
        return {
          ...order,
          advanceReceived: order.advanceReceived + amount,
          balanceAmount: newBalance,
          status: newBalance === 0 ? 'completed' : order.status,
          completedAt: newBalance === 0 ? new Date() : order.completedAt,
        };
      }
      return order;
    }));

    toast({
      title: 'Payment received',
      description: `₹${amount.toLocaleString()} payment recorded successfully`,
    });
    setIsPaymentDialogOpen(false);
    setPaymentAmount('');
    setSelectedOrder(null);
  };

  const handleWhatsApp = (order: Order) => {
    const message = encodeURIComponent(
      `Hello ${order.customerName}!\n\n` +
      `Your order #${order.invoiceNumber} is now ${order.status}.\n\n` +
      `Order Details:\n` +
      `- Product: ${order.items[0]?.productName}\n` +
      `- Total: ₹${order.totalAmount.toLocaleString()}\n` +
      `- Paid: ₹${order.advanceReceived.toLocaleString()}\n` +
      `- Balance: ₹${order.balanceAmount.toLocaleString()}\n\n` +
      `Thank you for choosing TailorPro!`
    );
    
    window.open(`https://wa.me/?text=${message}`, '_blank');
    
    setOrders(orders.map(o => 
      o.id === order.id ? { ...o, whatsappSent: true } : o
    ));
    
    toast({
      title: 'WhatsApp opened',
      description: 'Order details ready to send',
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <AlertCircle className="w-4 h-4" />;
      case 'processing': return <Clock className="w-4 h-4" />;
      case 'completed': return <CheckCircle2 className="w-4 h-4" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-amber-100 text-amber-700 border-amber-200';
      case 'processing': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'completed': return 'bg-emerald-100 text-emerald-700 border-emerald-200';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const updateStatus = (orderId: string, newStatus: 'pending' | 'processing' | 'completed') => {
    setOrders(orders.map(order => {
      if (order.id === orderId) {
        return {
          ...order,
          status: newStatus,
          completedAt: newStatus === 'completed' ? new Date() : order.completedAt,
        };
      }
      return order;
    }));
    toast({
      title: 'Status updated',
      description: `Order status changed to ${newStatus}`,
    });
  };

  return (
    <div className="p-6 lg:p-8 space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-3xl lg:text-4xl font-serif font-bold text-foreground">Orders</h1>
        <p className="text-muted-foreground mt-1">Track and manage all your orders</p>
      </div>

      {/* Search and Tabs */}
      <Card className="border-0 shadow-lg">
        <CardContent className="p-4 space-y-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              placeholder="Search by invoice or customer name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 h-12 bg-muted/30 border-0"
              data-testid="input-search-order"
            />
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4 h-12 bg-muted/50">
              <TabsTrigger value="all" className="data-[state=active]:bg-white data-[state=active]:shadow" data-testid="tab-all">
                All ({orders.length})
              </TabsTrigger>
              <TabsTrigger value="pending" className="data-[state=active]:bg-white data-[state=active]:shadow" data-testid="tab-pending">
                Pending ({orders.filter(o => o.status === 'pending').length})
              </TabsTrigger>
              <TabsTrigger value="processing" className="data-[state=active]:bg-white data-[state=active]:shadow" data-testid="tab-processing">
                Processing ({orders.filter(o => o.status === 'processing').length})
              </TabsTrigger>
              <TabsTrigger value="completed" className="data-[state=active]:bg-white data-[state=active]:shadow" data-testid="tab-completed">
                Completed ({orders.filter(o => o.status === 'completed').length})
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </CardContent>
      </Card>

      {/* Orders List */}
      <div className="space-y-4">
        {filteredOrders.map((order) => (
          <Card key={order.id} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300" data-testid={`card-order-${order.id}`}>
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                {/* Order Info */}
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-bold text-lg">{order.invoiceNumber}</h3>
                    <Badge className={`${getStatusColor(order.status)} border`}>
                      {getStatusIcon(order.status)}
                      <span className="ml-1 capitalize">{order.status}</span>
                    </Badge>
                  </div>
                  <p className="text-muted-foreground">{order.customerName}</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {order.items[0]?.productName} • {format(order.createdAt, 'dd MMM yyyy')}
                  </p>
                </div>

                {/* Payment Info */}
                <div className="flex flex-col sm:flex-row gap-4 lg:gap-8">
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Total</p>
                    <p className="text-lg font-bold">₹{order.totalAmount.toLocaleString()}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Paid</p>
                    <p className="text-lg font-bold text-emerald-600">₹{order.advanceReceived.toLocaleString()}</p>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">Balance</p>
                    <p className="text-lg font-bold text-amber-600">₹{order.balanceAmount.toLocaleString()}</p>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setSelectedOrder(order)}
                    data-testid={`button-view-${order.id}`}
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    View
                  </Button>
                  
                  {order.balanceAmount > 0 && (
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => {
                        setSelectedOrder(order);
                        setIsPaymentDialogOpen(true);
                      }}
                      data-testid={`button-payment-${order.id}`}
                    >
                      <CreditCard className="w-4 h-4 mr-1" />
                      Payment
                    </Button>
                  )}
                  
                  {order.status !== 'completed' && (
                    <Button 
                      size="sm"
                      className="bg-[hsl(222,47%,20%)] hover:bg-[hsl(222,47%,25%)] text-white"
                      onClick={() => updateStatus(order.id, order.status === 'pending' ? 'processing' : 'completed')}
                      data-testid={`button-status-${order.id}`}
                    >
                      {order.status === 'pending' ? 'Start Processing' : 'Mark Complete'}
                    </Button>
                  )}
                  
                  {order.status === 'completed' && (
                    <Button 
                      size="sm"
                      variant="outline"
                      className="text-emerald-600 border-emerald-200 hover:bg-emerald-50"
                      onClick={() => handleWhatsApp(order)}
                      data-testid={`button-whatsapp-${order.id}`}
                    >
                      <MessageCircle className="w-4 h-4 mr-1" />
                      WhatsApp
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {filteredOrders.length === 0 && (
          <Card className="border-0 shadow-lg">
            <CardContent className="p-12 text-center">
              <Clock className="w-16 h-16 text-muted-foreground/30 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-foreground">No orders found</h3>
              <p className="text-muted-foreground mt-1">Try adjusting your search or filter</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Order Details Dialog */}
      <Dialog open={!!selectedOrder && !isPaymentDialogOpen} onOpenChange={() => setSelectedOrder(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">Order Details</DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4 mt-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Invoice</span>
                <span className="font-medium">{selectedOrder.invoiceNumber}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Customer</span>
                <span className="font-medium">{selectedOrder.customerName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Product</span>
                <span className="font-medium">{selectedOrder.items[0]?.productName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Status</span>
                <Badge className={`${getStatusColor(selectedOrder.status)} border`}>
                  {selectedOrder.status.charAt(0).toUpperCase() + selectedOrder.status.slice(1)}
                </Badge>
              </div>
              <hr />
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Total Amount</span>
                <span className="font-bold text-lg">₹{selectedOrder.totalAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Paid</span>
                <span className="font-medium text-emerald-600">₹{selectedOrder.advanceReceived.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Balance</span>
                <span className="font-medium text-amber-600">₹{selectedOrder.balanceAmount.toLocaleString()}</span>
              </div>
              <hr />
              <div>
                <h4 className="font-medium mb-2">Measurements</h4>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  {selectedOrder.items[0]?.measurements.map((m) => (
                    <div key={m.id} className="flex justify-between bg-muted/50 p-2 rounded">
                      <span className="text-muted-foreground">{m.name}</span>
                      <span className="font-medium">{m.value} {m.unit}</span>
                    </div>
                  ))}
                </div>
              </div>
              {selectedOrder.items[0]?.notes && (
                <div>
                  <h4 className="font-medium mb-2">Notes</h4>
                  <p className="text-sm text-muted-foreground bg-muted/50 p-3 rounded">{selectedOrder.items[0].notes}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">Record Payment</DialogTitle>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4 mt-4">
              <div className="flex justify-between items-center p-4 bg-muted/50 rounded-lg">
                <span className="text-muted-foreground">Balance Due</span>
                <span className="font-bold text-xl text-amber-600">₹{selectedOrder.balanceAmount.toLocaleString()}</span>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Payment Amount</label>
                <div className="relative">
                  <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    type="number"
                    placeholder="Enter amount"
                    value={paymentAmount}
                    onChange={(e) => setPaymentAmount(e.target.value)}
                    className="pl-10 h-12"
                    max={selectedOrder.balanceAmount}
                    data-testid="input-payment-amount"
                  />
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1" onClick={() => setIsPaymentDialogOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  className="flex-1 bg-[hsl(222,47%,20%)] hover:bg-[hsl(222,47%,25%)] text-white"
                  onClick={handlePayment}
                  data-testid="button-confirm-payment"
                >
                  Confirm Payment
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
