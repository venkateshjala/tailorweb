import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Download,
  TrendingUp,
  Users,
  ShoppingBag,
  IndianRupee,
  Calendar
} from 'lucide-react';
import { mockOrders, mockCustomers, productTypes } from '@/lib/store';
import { format, subDays, isWithinInterval, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

const COLORS = ['#1e3a5f', '#f59e0b', '#10b981', '#8b5cf6', '#ec4899', '#06b6d4'];

export default function Reports() {
  const [dateRange, setDateRange] = useState('30');

  const now = new Date();
  const dateRanges: Record<string, { start: Date; end: Date }> = {
    '7': { start: subDays(now, 7), end: now },
    '30': { start: subDays(now, 30), end: now },
    '90': { start: subDays(now, 90), end: now },
    'thisMonth': { start: startOfMonth(now), end: now },
    'lastMonth': { start: startOfMonth(subMonths(now, 1)), end: endOfMonth(subMonths(now, 1)) },
  };

  const filteredOrders = mockOrders.filter(order => {
    const range = dateRanges[dateRange];
    return isWithinInterval(order.createdAt, { start: range.start, end: range.end });
  });

  const totalRevenue = filteredOrders.reduce((sum, order) => sum + order.totalAmount, 0);
  const totalCollected = filteredOrders.reduce((sum, order) => sum + order.advanceReceived, 0);
  const totalPending = filteredOrders.reduce((sum, order) => sum + order.balanceAmount, 0);
  const completedOrders = filteredOrders.filter(o => o.status === 'completed').length;

  // Product distribution
  const productDistribution = productTypes.map(product => {
    const count = filteredOrders.filter(order => 
      order.items.some(item => item.productType === product.id)
    ).length;
    return { name: product.name, value: count };
  }).filter(item => item.value > 0);

  // Revenue by status
  const revenueByStatus = [
    { name: 'Completed', value: filteredOrders.filter(o => o.status === 'completed').reduce((sum, o) => sum + o.totalAmount, 0), color: '#10b981' },
    { name: 'Processing', value: filteredOrders.filter(o => o.status === 'processing').reduce((sum, o) => sum + o.totalAmount, 0), color: '#3b82f6' },
    { name: 'Pending', value: filteredOrders.filter(o => o.status === 'pending').reduce((sum, o) => sum + o.totalAmount, 0), color: '#f59e0b' },
  ].filter(item => item.value > 0);

  // Daily orders trend (mock data for visualization)
  const dailyTrend = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(now, 6 - i);
    return {
      date: format(date, 'EEE'),
      orders: Math.floor(Math.random() * 5) + 1,
      revenue: Math.floor(Math.random() * 20000) + 5000,
    };
  });

  const stats = [
    { label: 'Total Revenue', value: `₹${totalRevenue.toLocaleString()}`, icon: IndianRupee, color: 'bg-blue-500' },
    { label: 'Collected', value: `₹${totalCollected.toLocaleString()}`, icon: TrendingUp, color: 'bg-emerald-500' },
    { label: 'Pending', value: `₹${totalPending.toLocaleString()}`, icon: Calendar, color: 'bg-amber-500' },
    { label: 'Orders', value: filteredOrders.length, icon: ShoppingBag, color: 'bg-purple-500' },
  ];

  return (
    <div className="p-6 lg:p-8 space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl lg:text-4xl font-serif font-bold text-foreground">Reports</h1>
          <p className="text-muted-foreground mt-1">Business analytics and insights</p>
        </div>
        
        <div className="flex gap-3">
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-40" data-testid="select-date-range">
              <SelectValue placeholder="Select range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
              <SelectItem value="thisMonth">This Month</SelectItem>
              <SelectItem value="lastMonth">Last Month</SelectItem>
            </SelectContent>
          </Select>
          
          <Button variant="outline" data-testid="button-export">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index} className="border-0 shadow-lg">
              <CardContent className="p-5">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl ${stat.color} flex items-center justify-center`}>
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.label}</p>
                    <p className="text-xl font-bold" data-testid={`stat-${stat.label.toLowerCase().replace(' ', '-')}`}>{stat.value}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Revenue Trend */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="font-serif text-lg">Revenue Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={dailyTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="date" stroke="#6b7280" fontSize={12} />
                  <YAxis stroke="#6b7280" fontSize={12} tickFormatter={(value) => `₹${value/1000}k`} />
                  <Tooltip 
                    formatter={(value: number) => [`₹${value.toLocaleString()}`, 'Revenue']}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="revenue" 
                    stroke="hsl(222, 47%, 20%)" 
                    strokeWidth={3}
                    dot={{ fill: 'hsl(222, 47%, 20%)', strokeWidth: 0, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Orders by Day */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="font-serif text-lg">Daily Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dailyTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis dataKey="date" stroke="#6b7280" fontSize={12} />
                  <YAxis stroke="#6b7280" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                  />
                  <Bar 
                    dataKey="orders" 
                    fill="hsl(38, 92%, 50%)" 
                    radius={[6, 6, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pie Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Product Distribution */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="font-serif text-lg">Product Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={productDistribution.length > 0 ? productDistribution : [{ name: 'No data', value: 1 }]}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {productDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap justify-center gap-4 mt-4">
              {productDistribution.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                  <span className="text-sm text-muted-foreground">{item.name} ({item.value})</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Revenue by Status */}
        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="font-serif text-lg">Revenue by Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={revenueByStatus.length > 0 ? revenueByStatus : [{ name: 'No data', value: 1, color: '#e5e7eb' }]}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {revenueByStatus.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value: number) => [`₹${value.toLocaleString()}`, 'Revenue']}
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap justify-center gap-4 mt-4">
              {revenueByStatus.map((item, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></div>
                  <span className="text-sm text-muted-foreground">{item.name} (₹{item.value.toLocaleString()})</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Order Details Table */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle className="font-serif text-lg">Recent Completed Orders</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Invoice</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Customer</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Product</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Amount</th>
                  <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Completed</th>
                </tr>
              </thead>
              <tbody>
                {filteredOrders.filter(o => o.status === 'completed').map((order) => (
                  <tr key={order.id} className="border-b border-border/50 hover:bg-muted/30 transition-colors" data-testid={`row-report-${order.id}`}>
                    <td className="py-3 px-4 text-sm font-medium">{order.invoiceNumber}</td>
                    <td className="py-3 px-4 text-sm">{order.customerName}</td>
                    <td className="py-3 px-4 text-sm">{order.items[0]?.productName}</td>
                    <td className="py-3 px-4 text-sm font-medium">₹{order.totalAmount.toLocaleString()}</td>
                    <td className="py-3 px-4 text-sm text-muted-foreground">
                      {order.completedAt ? format(order.completedAt, 'dd MMM yyyy') : '-'}
                    </td>
                  </tr>
                ))}
                {filteredOrders.filter(o => o.status === 'completed').length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-muted-foreground">
                      No completed orders in this period
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
