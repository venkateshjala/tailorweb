import { useState, useRef } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Search, 
  Plus, 
  ArrowRight, 
  ArrowLeft,
  Camera,
  X,
  CheckCircle2,
  IndianRupee,
  FileText
} from 'lucide-react';
import { 
  mockCustomers, 
  Customer, 
  productTypes, 
  measurementTemplates,
  Measurement,
  OrderItem,
  mockOrders
} from '@/lib/store';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

type Step = 'customer' | 'product' | 'measurements' | 'order' | 'complete';

export default function NewOrder() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [step, setStep] = useState<Step>('customer');
  const [customers] = useState<Customer[]>(mockCustomers);
  const [searchQuery, setSearchQuery] = useState('');
  const [isNewCustomerDialogOpen, setIsNewCustomerDialogOpen] = useState(false);
  
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<string | null>(null);
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [notes, setNotes] = useState('');
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  
  const [totalAmount, setTotalAmount] = useState('');
  const [advanceAmount, setAdvanceAmount] = useState('');
  
  const [newCustomer, setNewCustomer] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
  });

  const filteredCustomers = customers.filter(customer =>
    customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    customer.phone.includes(searchQuery)
  );

  const handleSelectCustomer = (customer: Customer) => {
    setSelectedCustomer(customer);
    setStep('product');
  };

  const handleAddNewCustomer = () => {
    if (!newCustomer.name || !newCustomer.phone) return;
    
    const customer: Customer = {
      id: String(customers.length + 1),
      ...newCustomer,
      createdAt: new Date(),
    };
    
    setSelectedCustomer(customer);
    setNewCustomer({ name: '', phone: '', email: '', address: '' });
    setIsNewCustomerDialogOpen(false);
    setStep('product');
  };

  const handleSelectProduct = (productId: string) => {
    setSelectedProduct(productId);
    const template = measurementTemplates[productId] || measurementTemplates['other'];
    setMeasurements(template.map((m, index) => ({
      id: String(index + 1),
      name: m.name,
      value: '',
      unit: m.unit,
    })));
    setStep('measurements');
  };

  const handleMeasurementChange = (id: string, value: string) => {
    setMeasurements(measurements.map(m => 
      m.id === id ? { ...m, value } : m
    ));
  };

  const handleImageCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setReferenceImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProceedToOrder = () => {
    const hasAllMeasurements = measurements.every(m => m.value.trim() !== '');
    if (!hasAllMeasurements) {
      toast({
        title: 'Missing measurements',
        description: 'Please fill in all measurement fields',
        variant: 'destructive',
      });
      return;
    }
    setStep('order');
  };

  const handleCreateOrder = () => {
    const total = parseFloat(totalAmount);
    const advance = parseFloat(advanceAmount) || 0;
    
    if (isNaN(total) || total <= 0) {
      toast({
        title: 'Invalid amount',
        description: 'Please enter a valid total amount',
        variant: 'destructive',
      });
      return;
    }
    
    if (advance > total) {
      toast({
        title: 'Invalid advance',
        description: 'Advance cannot be more than total amount',
        variant: 'destructive',
      });
      return;
    }

    const invoiceNumber = `INV-2024-${String(mockOrders.length + 1).padStart(3, '0')}`;
    
    toast({
      title: 'Order created!',
      description: `Invoice ${invoiceNumber} generated successfully`,
    });
    
    setStep('complete');
  };

  const stepIndicator = (currentStep: Step) => {
    const steps: Step[] = ['customer', 'product', 'measurements', 'order', 'complete'];
    const currentIndex = steps.indexOf(currentStep);
    
    return (
      <div className="flex items-center justify-center gap-2 mb-8">
        {steps.slice(0, 4).map((s, index) => (
          <div key={s} className="flex items-center">
            <div className={cn(
              "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all",
              index <= currentIndex 
                ? "bg-[hsl(222,47%,20%)] text-white" 
                : "bg-muted text-muted-foreground"
            )}>
              {index + 1}
            </div>
            {index < 3 && (
              <div className={cn(
                "w-12 h-0.5 mx-1",
                index < currentIndex ? "bg-[hsl(222,47%,20%)]" : "bg-muted"
              )} />
            )}
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="p-6 lg:p-8 space-y-6 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-3xl lg:text-4xl font-serif font-bold text-foreground">New Order</h1>
        <p className="text-muted-foreground mt-1">Create a new tailoring order</p>
      </div>

      {stepIndicator(step)}

      {/* Step 1: Select Customer */}
      {step === 'customer' && (
        <Card className="border-0 shadow-lg max-w-2xl mx-auto">
          <CardHeader>
            <CardTitle className="font-serif text-xl flex items-center justify-between">
              Select Customer
              <Dialog open={isNewCustomerDialogOpen} onOpenChange={setIsNewCustomerDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm" className="bg-[hsl(222,47%,20%)] hover:bg-[hsl(222,47%,25%)]" data-testid="button-new-customer">
                    <Plus className="w-4 h-4 mr-1" />
                    New Customer
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle className="font-serif">New Customer</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label>Full Name *</Label>
                      <Input
                        placeholder="Enter name"
                        value={newCustomer.name}
                        onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                        data-testid="input-new-customer-name"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Phone *</Label>
                      <Input
                        placeholder="+91 98765 43210"
                        value={newCustomer.phone}
                        onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value })}
                        data-testid="input-new-customer-phone"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Email</Label>
                      <Input
                        type="email"
                        placeholder="email@example.com"
                        value={newCustomer.email}
                        onChange={(e) => setNewCustomer({ ...newCustomer, email: e.target.value })}
                        data-testid="input-new-customer-email"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Address</Label>
                      <Input
                        placeholder="Full address"
                        value={newCustomer.address}
                        onChange={(e) => setNewCustomer({ ...newCustomer, address: e.target.value })}
                        data-testid="input-new-customer-address"
                      />
                    </div>
                    <Button onClick={handleAddNewCustomer} className="w-full bg-[hsl(222,47%,20%)] hover:bg-[hsl(222,47%,25%)]" data-testid="button-save-new-customer">
                      Add & Select Customer
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search customers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search-customer"
              />
            </div>
            
            <div className="max-h-80 overflow-y-auto space-y-2">
              {filteredCustomers.map((customer) => (
                <div
                  key={customer.id}
                  className="p-4 rounded-xl border border-border hover:border-[hsl(38,92%,50%)] hover:bg-muted/30 cursor-pointer transition-all"
                  onClick={() => handleSelectCustomer(customer)}
                  data-testid={`select-customer-${customer.id}`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[hsl(222,47%,20%)] text-white flex items-center justify-center font-bold">
                      {customer.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-medium">{customer.name}</p>
                      <p className="text-sm text-muted-foreground">{customer.phone}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Step 2: Select Product */}
      {step === 'product' && (
        <div className="max-w-3xl mx-auto space-y-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
            <Button variant="ghost" size="sm" onClick={() => setStep('customer')}>
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back
            </Button>
            <span>|</span>
            <span>Customer: <strong className="text-foreground">{selectedCustomer?.name}</strong></span>
          </div>
          
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="font-serif text-xl">Select Product Type</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {productTypes.map((product) => (
                  <div
                    key={product.id}
                    className="p-6 rounded-2xl border-2 border-border hover:border-[hsl(38,92%,50%)] hover:bg-muted/30 cursor-pointer transition-all text-center group"
                    onClick={() => handleSelectProduct(product.id)}
                    data-testid={`select-product-${product.id}`}
                  >
                    <div className="text-4xl mb-3 group-hover:scale-110 transition-transform">{product.icon}</div>
                    <p className="font-medium">{product.name}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Step 3: Measurements */}
      {step === 'measurements' && (
        <div className="max-w-3xl mx-auto space-y-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
            <Button variant="ghost" size="sm" onClick={() => setStep('product')}>
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back
            </Button>
            <span>|</span>
            <span>{selectedCustomer?.name} • {productTypes.find(p => p.id === selectedProduct)?.name}</span>
          </div>
          
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="font-serif text-xl">Enter Measurements</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {measurements.map((measurement) => (
                  <div key={measurement.id} className="space-y-2">
                    <Label className="text-sm">{measurement.name}</Label>
                    <div className="relative">
                      <Input
                        type="number"
                        placeholder="0"
                        value={measurement.value}
                        onChange={(e) => handleMeasurementChange(measurement.id, e.target.value)}
                        className="pr-16"
                        data-testid={`input-measurement-${measurement.name.toLowerCase().replace(' ', '-')}`}
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                        {measurement.unit}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Reference Image */}
              <div className="space-y-2">
                <Label>Reference Image (Optional)</Label>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handleImageCapture}
                  className="hidden"
                />
                
                {referenceImage ? (
                  <div className="relative w-40 h-40 rounded-xl overflow-hidden border-2 border-border">
                    <img src={referenceImage} alt="Reference" className="w-full h-full object-cover" />
                    <button
                      className="absolute top-2 right-2 w-6 h-6 bg-destructive text-white rounded-full flex items-center justify-center"
                      onClick={() => setReferenceImage(null)}
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    className="w-40 h-40 flex-col gap-2 border-dashed border-2"
                    onClick={() => fileInputRef.current?.click()}
                    data-testid="button-capture-image"
                  >
                    <Camera className="w-8 h-8 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">Take Photo</span>
                  </Button>
                )}
              </div>

              {/* Notes */}
              <div className="space-y-2">
                <Label>Additional Notes</Label>
                <Textarea
                  placeholder="Fabric color, style preferences, special instructions..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                  data-testid="input-notes"
                />
              </div>

              <Button 
                className="w-full h-12 bg-[hsl(222,47%,20%)] hover:bg-[hsl(222,47%,25%)] text-white"
                onClick={handleProceedToOrder}
                data-testid="button-proceed-to-order"
              >
                Proceed to Order
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Step 4: Create Order */}
      {step === 'order' && (
        <div className="max-w-2xl mx-auto space-y-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
            <Button variant="ghost" size="sm" onClick={() => setStep('measurements')}>
              <ArrowLeft className="w-4 h-4 mr-1" />
              Back
            </Button>
          </div>
          
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="font-serif text-xl">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Summary */}
              <div className="p-4 bg-muted/50 rounded-xl space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Customer</span>
                  <span className="font-medium">{selectedCustomer?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Product</span>
                  <span className="font-medium">{productTypes.find(p => p.id === selectedProduct)?.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Measurements</span>
                  <span className="font-medium">{measurements.length} recorded</span>
                </div>
              </div>

              {/* Payment Details */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Total Amount *</Label>
                  <div className="relative">
                    <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      type="number"
                      placeholder="Enter total amount"
                      value={totalAmount}
                      onChange={(e) => setTotalAmount(e.target.value)}
                      className="pl-10 h-12"
                      data-testid="input-total-amount"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label>Advance Received</Label>
                  <div className="relative">
                    <IndianRupee className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      type="number"
                      placeholder="Enter advance amount"
                      value={advanceAmount}
                      onChange={(e) => setAdvanceAmount(e.target.value)}
                      className="pl-10 h-12"
                      data-testid="input-advance-amount"
                    />
                  </div>
                </div>

                {totalAmount && (
                  <div className="p-4 bg-amber-50 rounded-xl">
                    <div className="flex justify-between items-center">
                      <span className="text-amber-700">Balance Amount</span>
                      <span className="text-xl font-bold text-amber-700">
                        ₹{(parseFloat(totalAmount) - (parseFloat(advanceAmount) || 0)).toLocaleString()}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              <Button 
                className="w-full h-12 bg-[hsl(222,47%,20%)] hover:bg-[hsl(222,47%,25%)] text-white"
                onClick={handleCreateOrder}
                data-testid="button-create-order"
              >
                <FileText className="w-5 h-5 mr-2" />
                Generate Invoice & Create Order
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Step 5: Complete */}
      {step === 'complete' && (
        <div className="max-w-md mx-auto text-center space-y-6">
          <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10 text-emerald-600" />
          </div>
          <div>
            <h2 className="text-2xl font-serif font-bold text-foreground">Order Created!</h2>
            <p className="text-muted-foreground mt-2">
              Invoice has been generated and the order is now in pending status.
            </p>
          </div>
          <div className="flex gap-3 justify-center">
            <Button variant="outline" onClick={() => setLocation('/orders')} data-testid="button-view-orders">
              View Orders
            </Button>
            <Button 
              className="bg-[hsl(222,47%,20%)] hover:bg-[hsl(222,47%,25%)] text-white"
              onClick={() => {
                setStep('customer');
                setSelectedCustomer(null);
                setSelectedProduct(null);
                setMeasurements([]);
                setNotes('');
                setReferenceImage(null);
                setTotalAmount('');
                setAdvanceAmount('');
              }}
              data-testid="button-new-order"
            >
              Create Another Order
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
