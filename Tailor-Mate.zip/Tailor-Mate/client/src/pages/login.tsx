import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Scissors } from 'lucide-react';

interface LoginProps {
  onLogin: (email: string, password: string) => void;
}

export default function Login({ onLogin }: LoginProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please enter both email and password');
      return;
    }
    onLogin(email, password);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[hsl(222,47%,15%)] via-[hsl(222,47%,20%)] to-[hsl(222,47%,25%)] p-4">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-[hsl(38,92%,50%)] rounded-full opacity-10 blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-[hsl(38,92%,50%)] rounded-full opacity-10 blur-3xl"></div>
      </div>
      
      <Card className="w-full max-w-md relative z-10 bg-white/95 backdrop-blur-xl border-0 shadow-2xl animate-slide-up">
        <CardHeader className="text-center pb-2">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-[hsl(222,47%,20%)] to-[hsl(222,47%,30%)] rounded-2xl flex items-center justify-center mb-4 shadow-lg">
            <Scissors className="w-8 h-8 text-[hsl(38,92%,50%)]" />
          </div>
          <CardTitle className="text-3xl font-serif text-[hsl(222,47%,15%)]">TailorPro</CardTitle>
          <CardDescription className="text-base text-muted-foreground">
            Professional Tailoring Management
          </CardDescription>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium">Email Address</Label>
              <Input
                id="email"
                type="email"
                placeholder="admin@tailorpro.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-12 bg-muted/50 border-border/50 focus:border-[hsl(38,92%,50%)] focus:ring-[hsl(38,92%,50%)]"
                data-testid="input-email"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-12 bg-muted/50 border-border/50 focus:border-[hsl(38,92%,50%)] focus:ring-[hsl(38,92%,50%)]"
                data-testid="input-password"
              />
            </div>
            
            {error && (
              <p className="text-sm text-destructive text-center" data-testid="text-error">{error}</p>
            )}
            
            <Button
              type="submit"
              className="w-full h-12 bg-gradient-to-r from-[hsl(222,47%,20%)] to-[hsl(222,47%,30%)] hover:from-[hsl(222,47%,25%)] hover:to-[hsl(222,47%,35%)] text-white font-medium text-base shadow-lg transition-all duration-300"
              data-testid="button-login"
            >
              Sign In
            </Button>
          </form>
          
          <p className="text-center text-sm text-muted-foreground mt-6">
            Demo: Use any email and password to login
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
